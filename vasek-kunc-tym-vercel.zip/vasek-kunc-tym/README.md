# Vašek Kunc & tým — balíček pro Vercel

Aktuální návrh webu, připravený jako statický HTML/CSS/JavaScript projekt.
Nepotřebuje databázi, proměnné prostředí ani instalaci závislostí.

## Obsah

- public/index.html — stránka a všechny texty
- public/style.css — responzivní vzhled
- public/script.js — mobilní menu a odkazy na detaily služeb
- public/assets/ — použité obrázky z vašich podkladů
- vercel.json — nastavení Vercelu

## Nasazení přes web Vercelu a GitHub

1. ZIP nejdřív rozbalte.
2. Obsah složky vasek-kunc-tym nahrajte do nového GitHub repozitáře.
   V kořeni repozitáře musí být vercel.json a složka public.
3. Ve Vercelu zvolte Add New → Project a importujte tento repozitář.
4. Framework Preset: Other. Root Directory: kořen repozitáře.
   Output Directory: public. Build Command a Install Command: prázdné.
   Přiložený vercel.json tato nastavení již obsahuje.
5. Tlačítkem Deploy web nasadíte.

## Alternativa bez GitHubu

S nainstalovaným Node.js otevřete terminál v rozbalené složce vasek-kunc-tym:

    npx vercel

Přihlaste se a postupujte podle otázek Vercelu. Příkaz vytvoří preview nasazení.
Pro produkční nasazení použijte:

    npx vercel --prod

Preview označuje typ nasazení, nikoli záruku neveřejného přístupu.
Případnou ochranu přístupu nastavte v projektu na Vercelu.

## Aktuální stav návrhu

Zůstává zachovaný aktuální vzhled a obsah webu, včetně noindex,nofollow.
Fotografie týmu je označený pracovní výřez; místa pro samostatné portréty
čekají na originály. Logo a ilustrace domu jsou CSS výřezy z dodaných podkladů.
Údaje provozovatele a vztah ke značce eDO dosud nejsou doplněné.
Kontaktní odkazy otevírají e-mailový program; žádná zpráva se automaticky
neodesílá. Balíček neobsahuje přístupové údaje ani lokální konfiguraci Sites.

Samotným vytvořením tohoto ZIPu nebyl web nikam nasazen.

Dokumentace:
https://vercel.com/docs/projects/deploy-from-cli
https://vercel.com/docs/builds/configure-a-build
https://vercel.com/docs/project-configuration/vercel-json
