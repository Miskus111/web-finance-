const menu=document.querySelector('.menu'),nav=document.querySelector('#nav');
function closeMenu(){menu.setAttribute('aria-expanded','false');nav.classList.remove('open')}
menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open)});
nav.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){closeMenu();menu.focus()}});
// Topic links open their corresponding service without hiding the other topics.
function openLinkedService(){const id=location.hash.slice(1);const target=document.getElementById(id);if(target?.matches('details.service'))target.open=true}
window.addEventListener('hashchange',openLinkedService);
openLinkedService();
document.querySelector('.hero-bottom').addEventListener('click',event=>{const link=event.target.closest('a[href^="#"]');if(!link)return;const target=document.getElementById(link.hash.slice(1));if(target?.matches('details.service'))target.open=true});
