# Finance web — náhled pro GitHub a Vercel

Balíček obsahuje aktuální designový návrh 01: úvod, všech 11 tematických variant služby a konzultační formulář. Jde o statické HTML/CSS/JS bez instalace závislostí a bez build kroku.

## Nahrání na GitHub

1. Rozbalte ZIP.
2. Do kořene zvoleného repozitáře nahrajte **obsah rozbaleného balíčku**: složku `public/`, `vercel.json`, `README.md` a `.gitignore` (skrytý soubor). Samotný ZIP se jako web nespustí.
3. Zachovejte složky a názvy souborů. `vercel.json` má být přímo v kořeni repozitáře, nikoli uvnitř `public/`.

## Vercel

Importujte tento GitHub repozitář do nového projektu Vercelu. Konfigurace je již ve `vercel.json`:

- Framework Preset: **Other**.
- Root Directory: **kořen repozitáře**.
- Build Command: **prázdný**, build se přeskočí.
- Install Command: **prázdný**, nic se neinstaluje.
- Output Directory: **public**.
- Environment Variables: **žádné**.

Žádný účet ani nasazení nebyly v rámci vytvoření ZIPu měněny. Pokud balíček umístíte do podsložky existujícího repozitáře, nastavte tuto podsložku jako Root Directory; musí obsahovat `vercel.json` i `public/`.

Konfigurace vychází z [dokumentace statických projektů Vercel](https://vercel.com/docs/builds/configure-a-build#skip-build-step) a [vercel.json](https://vercel.com/docs/project-configuration/vercel-json).

## Lokální otevření

Otevřete `public/index.html` v prohlížeči. Alternativně ze složky balíčku spusťte `python3 -m http.server 4173 --bind 127.0.0.1 --directory public` a otevřete http://127.0.0.1:4173/.

## Stav náhledu

- Formulář pouze lokálně ověřuje údaje. **Nic neodesílá ani neukládá**; nelze jej zatím používat ke sběru poptávek.
- Služby jsou tematické varianty `sluzba.html?tema=...`. Balíček nepředstírá hotových 15 samostatných produkčních URL.
- Zachováno označení pracovního návrhu a zákaz indexace (meta, robots.txt a hlavička). Nejde o omezení přístupu: zveřejněný náhled je dostupný lidem s adresou.
- Použitá fotografie/logo jsou výřezy jednoho dodaného referenčního obrázku. Samostatné originály, finální texty, provozní a právní údaje zůstávají k doplnění podle projektového briefu.
- Interní dokumentace, testovací screenshoty, letáky, Git historie, lokální konfigurace, Skills ani agenti nejsou součástí exportu.
